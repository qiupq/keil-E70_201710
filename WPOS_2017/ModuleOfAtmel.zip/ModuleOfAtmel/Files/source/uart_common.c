/* ---------------------------------------------------------------------------- */
/*                  Atmel Microcontroller Software Support                      */
/*                       SAM Software Package License                           */
/* ---------------------------------------------------------------------------- */
/* Copyright (c) 2015, Atmel Corporation                                        */
/*                                                                              */
/* All rights reserved.                                                         */
/*                                                                              */
/* Redistribution and use in source and binary forms, with or without           */
/* modification, are permitted provided that the following condition is met:    */
/*                                                                              */
/* - Redistributions of source code must retain the above copyright notice,     */
/* this list of conditions and the disclaimer below.                            */
/*                                                                              */
/* Atmel's name may not be used to endorse or promote products derived from     */
/* this software without specific prior written permission.                     */
/*                                                                              */
/* DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR   */
/* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF */
/* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE   */
/* DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,      */
/* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT */
/* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,  */
/* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    */
/* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING         */
/* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                           */
/* ---------------------------------------------------------------------------- */

/**
 * \file
 *
 * Implementation of UART (Universal Asynchronous Receiver Transmitter)
 * controller.
 *
 */
/*------------------------------------------------------------------------------
 *         Headers
 *----------------------------------------------------------------------------*/
#include "chip.h"

#include <assert.h>
#include <string.h>

#include "Common.h"
#include "pio_it.h"

/*------------------------------------------------------------------------------
 *         Exported functions
 *----------------------------------------------------------------------------*/
void UART_IRQ_FUCTION(Uart *pUart,uint32_t UART_CMPR_FLAG,IRQn_Type IRQ_NUM)
{
	/*	set IRQ function	*/
	pUart->UART_IER = UART_IER_CMP;
	pUart->UART_IDR = UART_IDR_CMP_EN;

	pUart->UART_CMPR = UART_CMPR_FLAG ;
	NVIC_ClearPendingIRQ(IRQ_NUM);

}
extern void UART_Init(void)
{
	Uart *pUart ;
	uint32_t uart_mode;
#if CONFIG_UART_1
	Pin pPins1[]=PINS_UART1_SUM; 
#endif
#if CONFIG_UART_2
	Pin pPins2[]=PINS_UART2_SUM; 
#endif
#if CONFIG_UART_3
	Pin pPins3[]=PINS_UART3_SUM; 
#endif

#if CONFIG_UART_1	
	/* uart 1 init */
	pUart = ( Uart *)CONSOLE_UART1;
	uart_mode = UART1_MODE;

	PIO_Configure(pPins1, PIO_LISTSIZE(pPins1));
	UART_Configure(pUart,uart_mode,UART_BAUDRATE,UART_BUS_CLOCK);
	UART_IRQ_FUCTION(pUart,UART_CMPR_UART1,UART1_IRQ_NUM);
	PMC_EnablePeripheral(CONSOLE_ID_UART1);
#endif 
#if CONFIG_UART_2	
	/* uart 2 init */
	pUart = ( Uart *)CONSOLE_UART2;
	uart_mode = UART2_MODE;

	PIO_Configure(pPins2, PIO_LISTSIZE(pPins2));
	UART_Configure(pUart,uart_mode,UART_BAUDRATE,UART_BUS_CLOCK);
	
	UART_IRQ_FUCTION(pUart,UART_CMPR_UART2,UART2_IRQ_NUM);
	PMC_EnablePeripheral(CONSOLE_ID_UART2);
#endif 
#if CONFIG_UART_3	
	/* uart 3 init */
	pUart = ( Uart *)CONSOLE_UART3;
	uart_mode = UART3_MODE;

	PIO_Configure(pPins3, PIO_LISTSIZE(pPins3));
	UART_Configure(pUart,uart_mode,UART_BAUDRATE,UART_BUS_CLOCK);
	UART_IRQ_FUCTION(pUart,UART_CMPR_UART3,UART3_IRQ_NUM);
	PMC_EnablePeripheral(CONSOLE_ID_UART3);
#endif 

}
extern WEAK int Uart_puts(Uart *uart,char *ptr)
{

	for (; *ptr != 0; ptr++)
		UART_PutChar(uart, *ptr);

	return 0;

}

extern WEAK char *Uart_gets(Uart *uart,char *ptr)
{
	uint8_t ch = 0;

	while (ch != '\r') {
		ch = UART_GetChar(uart);
		UART_PutChar(uart, ch);
		*(ptr++) = ch;
	}

	*ptr = '\0';
	return 0;

}
#if CONFIG_UART_2	
extern uint32_t SIMUART_RX_Available(void)
{
	Uart *pUart = ( Uart *)CONSOLE_UART2;

	return (pUart->UART_SR & UART_SR_RXRDY);
}

extern uint8_t SIM_UART_GetChar(void)
{

	return UART_GetChar(( Uart *)(CONSOLE_UART2));

}
extern int SIM_Write(const char *ptr)
{
	for (; *ptr != 0; ptr++)
		UART_PutChar(( Uart *)CONSOLE_UART2,*ptr);

	return 0;

}
extern int SIM_Writeln(const char *ptr)
{

	for (; *ptr != 0; ptr++)
		UART_PutChar(( Uart *)CONSOLE_UART2,*ptr);
	
	UART_PutChar(( Uart *)CONSOLE_UART2,'\r');
	UART_PutChar(( Uart *)CONSOLE_UART2,'\n');

	return 0;

}
#endif
#if CONFIG_UART_3	
extern uint32_t SAMPLE_UART_RX_Available(void)
{
	Uart *pUart = ( Uart *)(CONSOLE_UART3);

	return (pUart->UART_SR & UART_SR_RXRDY);
}

extern uint8_t SAMPLE_UART_GetChar(void)
{
	return UART_GetChar(( Uart *)(CONSOLE_UART3));

}

extern int SAMPLE_Write(const char *ptr)
{

	for (; *ptr != 0; ptr++)
		UART_PutChar(( Uart *)CONSOLE_UART3,*ptr);

	return 0;

}
extern int SAMPLE_Writeln(const char *ptr)
{

	for (; *ptr != 0; ptr++)
		UART_PutChar(( Uart *)CONSOLE_UART3,*ptr);
	
	UART_PutChar(( Uart *)CONSOLE_UART3,'\r');
	UART_PutChar(( Uart *)CONSOLE_UART3,'\n');

	return 0;

}
#endif
